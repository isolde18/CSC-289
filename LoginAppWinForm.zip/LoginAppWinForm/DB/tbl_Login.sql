﻿CREATE TABLE [dbo].[Table]
(
    [loginID] INT NOT NULL, 
    [username] NCHAR(50) NULL, 
    [password] NCHAR(50) NULL, 
    CONSTRAINT [PK_Table] PRIMARY KEY ([loginID])
)
