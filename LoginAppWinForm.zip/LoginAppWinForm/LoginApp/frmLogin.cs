﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace LoginApp
{
    public partial class frmLogin : Form
    {
        public frmLogin()
        {
            InitializeComponent();
        }

       
        public void BtnLogin_Click(object sender, EventArgs e)
        {
            SqlConnection sqlcon = new SqlConnection(@"Data Source = (LocalDB)\MSSQLLocalDB; AttachDbFilename = C:\Users\scott\source\repos\LoginAppWinForm\LoginDB.mdf; Integrated Security = True; Connect Timeout = 30");
            string query ="Select * from frmLogin where Username =  '" +txtUsername.Text.Trim() + "'and Password = '" + txtPassword.Text.Trim()+"'";
            //+btnLogin.Text.Trim();
            //+txtPassword.Text.Trim();
            
            SqlDataAdapter sda = new SqlDataAdapter(query, sqlcon);
            DataTable dtbl = new DataTable();
            sda.Fill(dtbl);
            
            if (dtbl.Rows.Count == 1)
            {
                frmMain objfrmMain = new frmMain();
                this.Hide();
                objfrmMain.Show();
            }

            else
            {
                MessageBox.Show("Check your username and password");
            }
            
        }

        private void BtnLogout_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
